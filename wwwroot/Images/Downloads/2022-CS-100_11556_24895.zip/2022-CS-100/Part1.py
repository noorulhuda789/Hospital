# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 04:19:18 2023

@author: HP
"""

import matplotlib.pyplot as plt 
import pandas as pd
"""df = pd.read_csv('population_by_country_2020.csv' ) 
print(df.dtypes)
list1 = df['Country (or dependency)'].values.tolist() 
list2 = df['Population (2020)'].values.tolist() 
plt.plot(list1, list2, color = 'red')
plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.title('Population by country')
plt.legend()
plt.show()

# Draw the line chart for the total number of steps on daily basis.
df = pd.read_csv('dailyActivity_merged.csv') 

# Assuming 'ActivityDate' contains dates in the format 'YYYY-MM-DD'
list1 = df['ActivityDate'].values.tolist()  # Dates on the x-axis
list2 = df['TotalSteps'].values.tolist()    # Total Steps on the y-axis

plt.plot(list1, list2, color='red')
plt.xlabel('Date')
plt.ylabel('Total Steps')
plt.title('Total Number of Steps on Daily Basis')
plt.legend()
plt.show()
#Draw the bar chart for the daily distance covered.
df = pd.read_csv('dailyActivity_merged.csv') 

list1 = df['ActivityDate'].values.tolist()  
list2 = df['TotalDistance'].values.tolist()    

plt.bar(list1, list2, color='red')
plt.xlabel('Date')
plt.ylabel('Total Distance')
plt.title('Daily distance Covered')
plt.legend()
plt.show()




#. Draw the scatter chart for the total time in the bed.
df = pd.read_csv('sleepDay_merged.csv') 

list1 = df['ActivityDate'].values.tolist()  
list2 = df['TotalTimeInBed'].values.tolist()    

plt.scatter(list1, list2, color='red',marker = '*')
plt.xlabel('Date')
plt.ylabel('Total Time in Bed')
plt.title('Total Time in Bed')
plt.legend()
plt.show()

"""
#Draw the Pie chart for the hourly steps on the 12th April 2016. 
df = pd.read_csv('hourlySteps_merged.csv')

# Convert the 'ActivityHour' column to a datetime format
df['ActivityHour'] = pd.to_datetime(df['ActivityHour'], format='%m/%d/%Y %I:%M:%S %p')

# Define the expected date
expected_date = pd.to_datetime('4/12/2016')

# Filter the data for the specified date
date_filter = df['ActivityHour'].dt.date == expected_date.date()
filtered_data = df[date_filter]

# Extract hourly steps and step counts
hourly_steps = filtered_data['ActivityHour'].dt.hour.values.tolist()
step_counts = filtered_data['StepTotal'].values.tolist()

# Labels for the pie chart (hours)
labels = [str(hour) + 'h' for hour in hourly_steps]

# Create the pie chart
plt.pie(step_counts, labels=labels, colors=['red', 'blue'], startangle=90, radius=0.9, autopct='%1.1f%%')
plt.xlabel('Hour of the Day')
plt.ylabel('Step Counts')
plt.title('Hourly Steps on April 12, 2016')
plt.legend()
plt.show()