--Q1
SELECT C.CustomerID, O.OrderID, O.OrderDate FROM Customers AS C LEFT JOIN (SELECT CustomerID, OrderID, OrderDate FROM Orders) AS O ON C.CustomerID = O.CustomerID;
--Q2
SELECT C.CustomerID FROM Customers AS C WHERE NOT EXISTS ( SELECT 1 FROM Orders AS O WHERE O.CustomerID = C.CustomerID);
--Q3
select O.CustomerID,O.OrderID,O.OrderDate from Orders as O where O.CustomerID IN (select CustomerID from Customers) and Year(o.OrderDate) = '1997'  and MONTH(o.OrderDate) = '7';
--Q4
select CustomerID,COUNT(customerID) as totalOrders from Orders where CustomerID IN (select CustomerID from Customers) group by CustomerID;
--Q5
SELECT e.EmployeeID, e.FirstName, e.LastName FROM Employees e CROSS JOIN (  SELECT 1 AS n UNION ALL     SELECT 2 UNION ALL     SELECT 3 UNION ALL    SELECT 4 UNION ALL  SELECT 5 ) AS sub ORDER BY e.EmployeeID, sub.n;
--Q6
select * from Products where UnitPrice > (select AVG(UnitPrice) from Products);
--Q7
SELECT MAX(UnitPrice) AS SecondHighestPrice FROM Products WHERE UnitPrice < (SELECT MAX(UnitPrice) FROM Products);
--Q8
Select O.EmployeeID,O.OrderDate From Orders as O where EmployeeID IN (select EmployeeID from Employees) and O.OrderDate > '1996-07-04' and O.OrderDate < '1997-08-04';
--Q9
SELECT CustomerID, TotalOrders, TotalQuantity FROM (SELECT C.CustomerID, COUNT(O.OrderID) AS TotalOrders, SUM(OD.Quantity) AS TotalQuantity FROM Customers AS C LEFT JOIN Orders AS O ON C.CustomerID = O.CustomerID LEFT JOIN [Order Details] AS OD ON O.OrderID = OD.OrderID WHERE C.Country = 'USA' GROUP BY C.CustomerID) AS US_Customers;
--Q10
SELECT C.CustomerID, C.CompanyName, OD.OrderID, O.OrderDate FROM Customers AS C JOIN Orders AS O ON C.CustomerID = O.CustomerID AND O.OrderDate = '1997-07-04' JOIN [Order Details] AS OD ON O.OrderID = OD.OrderID;
--Q11
SELECT e.EmployeeID, e.FirstName+' '+e.LastName AS EmployeeName, e.BirthDate, e.ReportsTo, (SELECT m.EmployeeID FROM Employees AS m WHERE m.EmployeeID=e.ReportsTo) AS ManagerID, (SELECT m.FirstName+' '+m.LastName FROM Employees AS m WHERE m.EmployeeID=e.ReportsTo) AS ManagerName, (SELECT m.BirthDate FROM Employees AS m WHERE m.EmployeeID=e.ReportsTo) AS ManagerBirthDate FROM Employees AS e WHERE e.ReportsTo IN (SELECT EmployeeID FROM Employees) AND e.BirthDate > (SELECT BirthDate FROM Employees AS m WHERE e.ReportsTo=m.EmployeeID);
--Q12
SELECT e.EmployeeID, E.FirstName+E.LastName as EmployeeName,e.BirthDate FROM Employees e WHERE  ReportsTo In (select EmployeeID from Employees) and e.BirthDate > (select BirthDate from Employees as m where e.ReportsTo = m.EmployeeID)
--Q13
SELECT ProductName, (SELECT OrderDate FROM Orders WHERE OrderID = OD.OrderID) AS OrderDate FROM Products AS p JOIN [Order Details] AS OD ON p.ProductID = OD.ProductID WHERE OD.OrderID IN (SELECT OrderID FROM Orders WHERE OrderDate = '1997-08-08');
--Q14
SELECT Address, City, Country FROM Customers WHERE CustomerID IN (SELECT O.CustomerID FROM Orders AS O WHERE O.RequiredDate < O.ShippedDate) AND ContactName = 'Anne';
--Q15
SELECT DISTINCT ShipCountry FROM Orders AS O WHERE EXISTS (SELECT 1 FROM [Order Details] AS OD JOIN Products AS P ON OD.ProductID = P.ProductID JOIN Categories AS C ON P.CategoryID = C.CategoryID WHERE OD.OrderID = O.OrderID AND C.CategoryName = 'Beverages');
