
# 1. Create a class KeyNode containing following attributesa. Key(String)
# b. Value(int)
# 2. Create a class MyHashTable, with the following attributes.
# • Array to list of KetNode objects
# • Size of HashTable
# • KeysOccupied(initially zero)
# 3. MyHashTable Contain the following functions
# a. Constructor(hsize) – create the array of size hsize
# b. GetHashTableSize()
# c. GetNumberOfKeys()
# d. HashFunction() – logic to calculate hash value
# e. UpdateKey(key, value)
# f. SearchKey(key)—returns value
# g. Rehash()—in case of hash table is full
# h. Display()—display all the keys and values

class KeyNode:
    def __init__(self,key,value):
        self.key = key
        self.value = value
        self.next = None
class MyHashTable:
    def __init__(self,hsize):
        self.hsize = hsize
        self.keysOccupied = 0
        self.array = [None]*hsize
    def getHashTableSize(self):
        return self.hsize
    def getNumberOfKeys(self):
        return self.keysOccupied
    def hashFunction(self,key):
        sum = 0
        for i in range(len(key)):
            sum = sum + ord(key[i])
        return sum % self.hsize
    def updateKey(self,key,value):
        hashIndex = self.hashFunction(key)
        if self.array[hashIndex] == None:
            self.array[hashIndex] = KeyNode(key,value)
            self.keysOccupied += 1
        else:
            temp = self.array[hashIndex]
            while temp.next != None:
                if temp.key == key:
                    temp.value += 1
                    break
                temp = temp.next
            if temp.key == key:
                temp.value += 1
            else:
                temp.next = KeyNode(key,value)
                self.keysOccupied += 1
    def searchKey(self,key):
        hashIndex = self.hashFunction(key)
        if self.array[hashIndex] == None:
            return None
        else:
            temp = self.array[hashIndex]
            while temp.next != None:
                if temp.key == key:
                    return temp.value
                temp = temp.next
            if temp.key == key:
                return temp.value
            else:
                return None
    def rehash(self):
        self.hsize = self.hsize * 2
        temp = self.array
        self.array = [None] * self.hsize
        for i in range(len(temp)):
            if temp[i] != None:
                self.updateKey(temp[i].key,temp[i].value)
    def display(self):
        for i in range(len(self.array)):
            if self.array[i] != None:
                temp = self.array[i]
                while temp.next != None:
                    print(temp.key,temp.value)
                    temp = temp.next
                print(temp.key,temp.value)
#Your program will use a hash table to count the number of occurrences of words in a text file. The basic algorithm
#goes as follows. For each word in the file:
# Look up the word in the hash table.
# • If it isn’t there, add it to the hash table with a value of 1. In this case you’ll have to create a new object
# and link it to the hash table as described above.
# • If it is there, add 1 to its value. In this case you don’t create a new object.
# • At the end of the program, you should output all the words in the file, one per line, with the count next to
# the word e.g.
# cat 2
# hat 4
# green 12
if __name__ == '__main__':
    hsize = int(input("Enter the hash table size: "))
    obj = MyHashTable(hsize)
    file = open("text.txt","r")
    for line in file:
        for word in line.split():
            obj.updateKey(word,1)
    obj.display()
    file.close()
    



