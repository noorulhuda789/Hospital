﻿namespace WindowsFormsApp2
{
    partial class Course
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Edit = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.CourseName = new System.Windows.Forms.TextBox();
            this.Semester = new System.Windows.Forms.TextBox();
            this.TeacherName = new System.Windows.Forms.TextBox();
            this.StudentName = new System.Windows.Forms.TextBox();
            this.CourseID = new System.Windows.Forms.TextBox();
            this.TeacherNameField = new System.Windows.Forms.Label();
            this.SemesterField = new System.Windows.Forms.Label();
            this.StudentNameField = new System.Windows.Forms.Label();
            this.CourseNameField = new System.Windows.Forms.Label();
            this.CourseIDField = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1028, 100);
            this.panel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "Courses";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Edit
            // 
            this.Edit.Location = new System.Drawing.Point(317, 330);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(166, 50);
            this.Edit.TabIndex = 29;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = true;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(568, 330);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(166, 50);
            this.Delete.TabIndex = 28;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(819, 330);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(166, 50);
            this.Reset.TabIndex = 27;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(63, 330);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 50);
            this.button1.TabIndex = 26;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CourseName
            // 
            this.CourseName.Location = new System.Drawing.Point(677, 139);
            this.CourseName.Name = "CourseName";
            this.CourseName.Size = new System.Drawing.Size(100, 26);
            this.CourseName.TabIndex = 25;
            // 
            // Semester
            // 
            this.Semester.Location = new System.Drawing.Point(186, 270);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(100, 26);
            this.Semester.TabIndex = 24;
            // 
            // TeacherName
            // 
            this.TeacherName.Location = new System.Drawing.Point(677, 205);
            this.TeacherName.Name = "TeacherName";
            this.TeacherName.Size = new System.Drawing.Size(100, 26);
            this.TeacherName.TabIndex = 23;
            // 
            // StudentName
            // 
            this.StudentName.Location = new System.Drawing.Point(271, 201);
            this.StudentName.Name = "StudentName";
            this.StudentName.Size = new System.Drawing.Size(100, 26);
            this.StudentName.TabIndex = 22;
            // 
            // CourseID
            // 
            this.CourseID.Location = new System.Drawing.Point(271, 139);
            this.CourseID.Name = "CourseID";
            this.CourseID.Size = new System.Drawing.Size(100, 26);
            this.CourseID.TabIndex = 21;
            // 
            // TeacherNameField
            // 
            this.TeacherNameField.AutoSize = true;
            this.TeacherNameField.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeacherNameField.Location = new System.Drawing.Point(483, 203);
            this.TeacherNameField.Name = "TeacherNameField";
            this.TeacherNameField.Size = new System.Drawing.Size(161, 26);
            this.TeacherNameField.TabIndex = 20;
            this.TeacherNameField.Text = "TeacherName:";
            // 
            // SemesterField
            // 
            this.SemesterField.AutoSize = true;
            this.SemesterField.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SemesterField.Location = new System.Drawing.Point(58, 268);
            this.SemesterField.Name = "SemesterField";
            this.SemesterField.Size = new System.Drawing.Size(113, 26);
            this.SemesterField.TabIndex = 19;
            this.SemesterField.Text = "Semester:";
            // 
            // StudentNameField
            // 
            this.StudentNameField.AutoSize = true;
            this.StudentNameField.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentNameField.Location = new System.Drawing.Point(58, 201);
            this.StudentNameField.Name = "StudentNameField";
            this.StudentNameField.Size = new System.Drawing.Size(158, 26);
            this.StudentNameField.TabIndex = 18;
            this.StudentNameField.Text = "StudentName:";
            // 
            // CourseNameField
            // 
            this.CourseNameField.AutoSize = true;
            this.CourseNameField.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseNameField.Location = new System.Drawing.Point(483, 137);
            this.CourseNameField.Name = "CourseNameField";
            this.CourseNameField.Size = new System.Drawing.Size(152, 26);
            this.CourseNameField.TabIndex = 17;
            this.CourseNameField.Text = "CourseName:";
            // 
            // CourseIDField
            // 
            this.CourseIDField.AutoSize = true;
            this.CourseIDField.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseIDField.Location = new System.Drawing.Point(58, 137);
            this.CourseIDField.Name = "CourseIDField";
            this.CourseIDField.Size = new System.Drawing.Size(119, 26);
            this.CourseIDField.TabIndex = 16;
            this.CourseIDField.Text = "CourseID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(63, 414);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(922, 261);
            this.dataGridView1.TabIndex = 30;
            // 
            // Course
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CourseName);
            this.Controls.Add(this.Semester);
            this.Controls.Add(this.TeacherName);
            this.Controls.Add(this.StudentName);
            this.Controls.Add(this.CourseID);
            this.Controls.Add(this.TeacherNameField);
            this.Controls.Add(this.SemesterField);
            this.Controls.Add(this.StudentNameField);
            this.Controls.Add(this.CourseNameField);
            this.Controls.Add(this.CourseIDField);
            this.Controls.Add(this.panel1);
            this.Name = "Course";
            this.Size = new System.Drawing.Size(1028, 678);
            this.Load += new System.EventHandler(this.Course_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox CourseName;
        private System.Windows.Forms.TextBox Semester;
        private System.Windows.Forms.TextBox TeacherName;
        private System.Windows.Forms.TextBox StudentName;
        private System.Windows.Forms.TextBox CourseID;
        private System.Windows.Forms.Label TeacherNameField;
        private System.Windows.Forms.Label SemesterField;
        private System.Windows.Forms.Label StudentNameField;
        private System.Windows.Forms.Label CourseNameField;
        private System.Windows.Forms.Label CourseIDField;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
