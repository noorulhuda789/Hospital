﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.MainMenu = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Student = new System.Windows.Forms.Button();
            this.Course = new System.Windows.Forms.Button();
            this.Enrollments = new System.Windows.Forms.Button();
            this.Attendance = new System.Windows.Forms.Button();
            this.panelContainer = new System.Windows.Forms.Panel();
            this.MainMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(23, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "LMS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainMenu
            // 
            this.MainMenu.Controls.Add(this.Attendance);
            this.MainMenu.Controls.Add(this.Enrollments);
            this.MainMenu.Controls.Add(this.Course);
            this.MainMenu.Controls.Add(this.Student);
            this.MainMenu.Controls.Add(this.panel1);
            this.MainMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(200, 678);
            this.MainMenu.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 2;
            // 
            // Student
            // 
            this.Student.Dock = System.Windows.Forms.DockStyle.Top;
            this.Student.Location = new System.Drawing.Point(0, 100);
            this.Student.Name = "Student";
            this.Student.Size = new System.Drawing.Size(200, 93);
            this.Student.TabIndex = 2;
            this.Student.Text = "Student";
            this.Student.UseVisualStyleBackColor = true;
            this.Student.Click += new System.EventHandler(this.Student_Click);
            // 
            // Course
            // 
            this.Course.Dock = System.Windows.Forms.DockStyle.Top;
            this.Course.Location = new System.Drawing.Point(0, 193);
            this.Course.Name = "Course";
            this.Course.Size = new System.Drawing.Size(200, 93);
            this.Course.TabIndex = 3;
            this.Course.Text = "Course";
            this.Course.UseVisualStyleBackColor = true;
            this.Course.Click += new System.EventHandler(this.Course_Click);
            // 
            // Enrollments
            // 
            this.Enrollments.Dock = System.Windows.Forms.DockStyle.Top;
            this.Enrollments.Location = new System.Drawing.Point(0, 286);
            this.Enrollments.Name = "Enrollments";
            this.Enrollments.Size = new System.Drawing.Size(200, 93);
            this.Enrollments.TabIndex = 4;
            this.Enrollments.Text = "Enrollments";
            this.Enrollments.UseVisualStyleBackColor = true;
            this.Enrollments.Click += new System.EventHandler(this.Enrollments_Click);
            // 
            // Attendance
            // 
            this.Attendance.Dock = System.Windows.Forms.DockStyle.Top;
            this.Attendance.Location = new System.Drawing.Point(0, 379);
            this.Attendance.Name = "Attendance";
            this.Attendance.Size = new System.Drawing.Size(200, 93);
            this.Attendance.TabIndex = 5;
            this.Attendance.Text = "Attendance";
            this.Attendance.UseVisualStyleBackColor = true;
            this.Attendance.Click += new System.EventHandler(this.Attendance_Click);
            // 
            // panelContainer
            // 
            this.panelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContainer.Location = new System.Drawing.Point(200, 0);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Size = new System.Drawing.Size(1028, 678);
            this.panelContainer.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1228, 678);
            this.Controls.Add(this.panelContainer);
            this.Controls.Add(this.MainMenu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MainMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel MainMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Student;
        private System.Windows.Forms.Button Enrollments;
        private System.Windows.Forms.Button Course;
        private System.Windows.Forms.Button Attendance;
        private System.Windows.Forms.Panel panelContainer;
    }
}

