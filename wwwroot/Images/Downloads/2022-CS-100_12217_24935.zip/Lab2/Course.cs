﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Course : UserControl
    {
        private DataTable dt;
        public Course()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Course values (@Course_ID, @Course_Name,@Student_Name,@Teacher_Name,@Semester)", con);
            cmd.Parameters.AddWithValue("@Course_ID", CourseID.Text);
            cmd.Parameters.AddWithValue("@Course_Name", CourseName.Text);
            cmd.Parameters.AddWithValue("@Student_Name", StudentName.Text);
            cmd.Parameters.AddWithValue("@Teacher_Name", TeacherName.Text);
            cmd.Parameters.AddWithValue("@Semester", Semester.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            cmd = new SqlCommand("Select * from Course", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Course_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Course", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the value of the CourseId column
                string courseId = selectedRow.Cells["Course_ID"].Value.ToString();

                // Remove the row from the DataTable
                DataRow[] rowsToDelete = dt.Select("Course_ID = '" + courseId + "'");
                foreach (DataRow rowToDelete in rowsToDelete)
                {
                    dt.Rows.Remove(rowToDelete);
                }

                // Update the DataGridView
                dataGridView1.DataSource = dt;

                /*// Delete the row from the database
                using (SqlConnection con = Configuration.getInstance().getConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Course WHERE Course_ID = @Course_ID", con))
                    {
                        cmd.Parameters.AddWithValue("@Course_ID", courseId);
                        cmd.ExecuteNonQuery();
                    }
                }
            }*/
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }

        }
    }
}
