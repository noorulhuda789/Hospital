﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void adduserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            panelContainer.Controls.Clear();
            panelContainer.Controls.Add(userControl);
            userControl.BringToFront();

        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Student student = new Student();
            adduserControl(student);
        }

        private void Student_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            adduserControl(student);
        }

        private void Course_Click(object sender, EventArgs e)
        {
            Course courses = new Course();
            adduserControl(courses);
        }

        private void Enrollments_Click(object sender, EventArgs e)
        {
            Enrollments enrollments = new Enrollments();
            adduserControl(enrollments);
        }

        private void Attendance_Click(object sender, EventArgs e)
        {
            Attendance attendancesheet = new Attendance();
            adduserControl(attendancesheet);
        }
    }
}
