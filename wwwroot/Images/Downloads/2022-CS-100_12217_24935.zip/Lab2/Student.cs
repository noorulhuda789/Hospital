﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Student : UserControl
    {
        private DataTable dt;
        public Student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Student values (@ID, @Name,@Department,@Session,@Address)", con);
            cmd.Parameters.AddWithValue("@ID", RegNoS.Text);
            cmd.Parameters.AddWithValue("@Name", SessionS.Text);
            cmd.Parameters.AddWithValue("@Department", DepartmentS.Text);
            cmd.Parameters.AddWithValue("@Session", DepartmentS.Text);
            cmd.Parameters.AddWithValue("@Address", DepartmentS.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Student_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the value of the CourseId column
                string regNo = selectedRow.Cells["RegisterationNumber"].Value.ToString();

                // Remove the row from the DataTable
                DataRow[] rowsToDelete = dt.Select("RegisterationNumber = '" + regNo + "'");
                foreach (DataRow rowToDelete in rowsToDelete)
                {
                    dt.Rows.Remove(rowToDelete);
                }

                // Update the DataGridView
                dataGridView1.DataSource = dt;

                /*// Delete the row from the database
                using (SqlConnection con = Configuration.getInstance().getConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Course WHERE RegisterationNumber = @RegisterationNumber", con))
                    {
                        cmd.Parameters.AddWithValue("@RegisterationNumber", regNo);
                        cmd.ExecuteNonQuery();
                    }
                }
            }*/
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }
    }
}
