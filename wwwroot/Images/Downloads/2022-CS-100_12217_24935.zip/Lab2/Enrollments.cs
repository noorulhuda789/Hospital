﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Enrollments : UserControl
    {
        private DataTable dt;
        public Enrollments()
        {
            InitializeComponent();
        }

        private void Enrollments_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Enrollments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Enrollments values (@StudentRegNo, @CourseName)", con);
            cmd.Parameters.AddWithValue("@StudentRegNo", RegNoS.Text);
            cmd.Parameters.AddWithValue("@CourseName", CourseNameS.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            cmd = new SqlCommand("Select * from Enrollments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            // Check if a row is selected
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Get the value of the CourseId column
                string regNo = selectedRow.Cells["StudentRegNo"].Value.ToString();

                // Remove the row from the DataTable
                DataRow[] rowsToDelete = dt.Select("StudentRegNo = '" + regNo + "'");
                foreach (DataRow rowToDelete in rowsToDelete)
                {
                    dt.Rows.Remove(rowToDelete);
                }

                // Update the DataGridView
                dataGridView1.DataSource = dt;

                /*// Delete the row from the database
                using (SqlConnection con = Configuration.getInstance().getConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Course WHERE StudentRegNo = @StudentRegNo", con))
                    {
                        cmd.Parameters.AddWithValue("@StudentRegNo", regNo);
                        cmd.ExecuteNonQuery();
                    }
                }
            }*/
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }
    }
}
