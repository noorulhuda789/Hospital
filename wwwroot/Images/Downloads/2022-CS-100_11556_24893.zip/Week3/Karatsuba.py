# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 08:02:51 2023

@author: HP
"""
def Multiply_integer(a,b):
    result = int(a*b)
    return str(result)
def Multiply_string(a,b):
    result = int(a) * int(b)
    return str(result)
#(a+b)(c+d) - ac - bd Karatsuba Formula
def Karatsuba(a, b):
    if len(a) == 1 or len(b) == 1:
        return int(a) * int(b)
    n = max(len(a), len(b))
    m = n//2
    a_high, a_low = a[:-m], a[-m:]
    b_high, b_low = b[:-m], b[-m:]
    a_c = int(a_high) * int(b_high)
    b_d = int(a_low) * int(b_low)
    ad_bc = (int(a_high)+int(a_low))*(int(b_high)+int(b_low)) - a_c - b_d
    result = (a_c * 10**(2*m)) + (ad_bc * 10**m) + b_d
    print(result)
def Multiply_Recursive(a, b) :
    if len(a) == 1 or len(b) == 1:
        return int(a) * int(b)
    n = max(len(a), len(b))
    m = n//2
    a_high, a_low = a[:-m], a[-m:]
    b_high, b_low = b[:-m], b[-m:]
    a_c = Multiply_Recursive(a_high,b_high)
    b_d = Multiply_Recursive(a_low,b_low)
    ad_bc =  Multiply_Recursive(str(int(a_high) + int(a_low)), str(int(b_high) + int(b_low))) - a_c - b_d
    result = (a_c * 10**(2*m)) + (ad_bc * 10**m) + b_d
    return str(result)
a = "110"
b = "3333"
result = Karatsuba(a, b)
print(Multiply_Recursive(a, b))
#print(result)

#Karatsuba("110","3333")