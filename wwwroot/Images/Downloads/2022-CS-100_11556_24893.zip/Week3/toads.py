# -*- coding: utf-8 -*-
"""
Created on Thu Sep 21 14:27:01 2023

@author: HP
"""

import random 
class Toad:
 def __init__(self, is_trustworthy):
     self.truthful: bool = bool(int(is_trustworthy))
 
 def is_trustworthy(self):
     return self.truthful
 def tell_about(self,toad):
     b_trustworthy= toad.is_trustworthy() 
     if(self.is_trustworthy()):
         return b_trustworthy
     else:
         r = random.random()
         if(r<0.5):
             return True
         else:
             return False
      
def getPopulation(n):
    population = []
    for i in range(n):
        is_trustworthy = random.choice([0, 1])
        toad = Toad(is_trustworthy)
        population.append(toad)
    return population
def TruthFulToadsA(population):
    truthful_indices = []

    for i in range(len(population)):
            if population[i].is_trustworthy():
                truthful_indices.append(i)

    return truthful_indices
def TruthFulToadsB(population):
    truthful_indices = []
    for i in range(0,len(population),2):
        if population[i].is_trustworthy():
            truthful_indices.append(i)
    return truthful_indices
def TruthFulToadsC(population):
    truthful_indices = []
    for i in range(1,len(population),2):
        if population[i].is_trustworthy():
            truthful_indices.append(i)
    return truthful_indices

arr = getPopulation(8)
arr3 = TruthFulToadsA(arr)
arr4 = TruthFulToadsB(arr)
arr5 = TruthFulToadsC(arr)
print(arr,arr3,arr4,arr5)        
        

#def TruthFulToadsA(population):
toad1 = Toad(0)  # Trustworthy toad
toad2 = Toad(1)  # Untrustworthy toad

result = toad1.tell_about(toad2)
#print(result)  # This will print True or False based on random chance
