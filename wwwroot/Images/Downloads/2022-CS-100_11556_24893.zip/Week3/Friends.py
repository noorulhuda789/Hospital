# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 08:28:53 2023

@author: HP
"""

arr = []

def friendSlower(Input):
    for i in range(len(Input)): # solving the problem using n^2 time complexity
        for k in range(i+1, len(Input)): # starting the array from i+1 to solve the problem of checking for the same element
            if (Input[i][0] <= Input[k][1] and Input[i][1] >= Input[k][0]): # checking for the overlapping of the two time are they present in the class at any point or not
                r = (i+1, k+1)  # Create the tuple for overlapping elements
                arr.append(r)
    return Input

def friendFaster(Input):
    Index = []
    for i in range(len(Input)):
        Index.append(i+1)
    i = 0
    k = i+1
    MergeSort(Input, 0, len(Input)-1,0)
    while(i!=len(Input)):
        if(k==len(Input)):
            k+=1
        elif (Input[i][0] <= Input[k][1] and Input[i][1] >= Input[k][0]):
            r = (i+1,k+1)
            arr.append(r)
            k+=1
        else:
            i+=1 
            k= i+1
            
     MergeSort(Input, 0, len(Input)-1,1)
     i = 0
     k = i+1
     
     while(i!=len(Input)):
         if(k==len(Input)):
             k+=1
         elif (Input[i][0] <= Input[k][1] and Input[i][1] >= Input[k][0]):
             r = (i+1,k+1)
             arr.append(r)
             k+=1
         else:
             i+=1 
             k= i+1
def Merge(array, p, q, r,index):
    n1 = q - p + 1
    n2 = r - q

    # Create temporary arrays for the left and right subarrays
    left_array = [0] * (n1)
    right_array = [0] * (n2)

    # Copy data to temporary arrays left_array[] and right_array[]
    for i in range(n1):
        left_array[i] = array[p + i]

    for i in range(n2):
        right_array[i] = array[q + 1 + i]

    i = 0  # Initial index of the first subarray
    j = 0  # Initial index of the second subarray
    k = p  # Initial index of the merged subarray

    while i < n1 and j < n2:
        if left_array[i][index] <= right_array[j][index]:
            array[k] = left_array[i]
            i += 1
        else:
            array[k] = right_array[j]
            j += 1
        k += 1

    # Copy the remaining elements of left_array[], if any
    while i < n1:
        array[k] = left_array[i]
        i += 1
        k += 1

    # Copy the remaining elements of right_array[], if any
    while j < n2:
        array[k] = right_array[j]
        j += 1
        k += 1

def MergeSort(array, p, r,index):
    if p < r:
        q = (p + r) // 2  # Calculate the midpoint
        MergeSort(array, p, q,index)  # Sort the first half
        MergeSort(array, q + 1, r,index)  # Sort the second half
        Merge(array, p, q, r,index)  # Merge the two sorted halves

# Example usage:

