#include <iostream>
#include <stdio.h>
#include <conio.h>
using namespace std;
class Node
{
public:
    int data;
    Node *parent;
    Node *left;
    Node *right;

    Node(int data) : data(data), parent(nullptr), left(nullptr), right(nullptr) {}
};
class BST
{
public:
    BST() : root(nullptr) {} // Constructor

    BST(int arr[], int size) : root(nullptr)
    {
        for (int i = 0; i < size; ++i)
        {
            insertNode(arr[i]);
        }
    }

    ~BST() { delete (root); } // Destructor

    bool isEmpty() { return root == nullptr; }

    Node *getTree() { return root; }
    Node *insertNode(int x)
    {
        if (isEmpty())
        {
            root = new Node(x);
            return root;
        }

        Node *currentNode = root;
        Node *parent = nullptr;

        while (currentNode != nullptr)
        {
            parent = currentNode;
            if (x < currentNode->data)
            {
                currentNode = currentNode->left;
            }
            else
            {
                currentNode = currentNode->right;
            }
        }

        Node *newNode = new Node(x);
        newNode->parent = parent;

        if (x < parent->data)
        {
            parent->left = newNode;
        }
        else
        {
            parent->right = newNode;
        }

        return newNode;
    } // insert node  in bst
    Node *findNode(int x)
    {
        Node *temp = root;
        while ((temp != NULL) && (temp->data != x))
        {
            if (temp->data > x)
                temp = temp->left;
            else
                temp = temp->right;
        }
        return temp;
    } // search for data value x in the BST, if not found, return the last value before null
    bool deleteNode(int x)
    {
        bool status = false;
        Node *temp = findNode(x);

        if (temp == NULL)
        {
            std::cout << "Data " << x << " does not exist in the tree." << std::endl;
            return status;
        }

        if (temp->left == NULL || temp->right == NULL)
        {
            Node *child = temp->left ? temp->left : temp->right;
            Node *parent = temp->parent;
            if (parent->left == temp)
                parent->left = child;
            else
                parent->right = child;
            free(temp);
            status = true;
        }
        else
        {
            Node *successorParent = temp;
            Node *successor = temp->right;
            while (successor->left != NULL)
            {
                successorParent = successor;
                successor = successor->left;
            }
            int temp_val = successor->data;
            deleteNode(temp_val);
            temp->data = temp_val;
            status = true;
        }
        return status;
    } // delete all occurrences of x (use transplant as helping procedure in book)
    void inOrderTraversal(Node *T)
    {
        while (!isEmpty())
        {
            inOrderTraversal(T->left);
            printf("%d ", T->data);
            inOrderTraversal(T->right);
        }
    } // prints using in order traversal technique
    void preOrderTraversal(Node *T)
    {
        while (!isEmpty())
        {
            printf("%d ", T->data);
            preOrderTraversal(T->left);
            preOrderTraversal(T->right);
        }
    } // prints using in pre traversal technique
    void postOrderTraversal(Node *T)
    {
        while (!isEmpty())
        {
            postOrderTraversal(T->left);
            postOrderTraversal(T->right);
            printf("%d ", T->data);
        }

    } // prints using in post traversal technique
    int NumberOfNodes(Node *T)
    {
        Node *temp = root;
        int count = 0;
        while (!isEmpty())
        {
            count++;
            temp = temp->right;
        }
        return count;
    } // recursive procedure to find number of nodes in tree T
    int Height(Node *T)
    {
        if (root == NULL)
            return -1;
        else
        {
            int leftHeight = Height(root->left);
            int rightHeight = Height(root->right);
            if (leftHeight > rightHeight)
                return (leftHeight + 1);
            else
                return (rightHeight + 1);
        }
    } // recursive procedure to calculate the height in tree T
    bool isBST(Node *T)
    {
        if (T == NULL)
            return true;
        else
        {
            if ((isBST(T->left)) && (isBST(T->right)))
                return true;
            else
                return false;
        }
    }
    void LeafNodes(Node *T)
    {
        if (T != NULL)
        {
            if (T->left == NULL && T->right == NULL)
                printf("%d\n", T->data);
            else
            {
                LeafNodes(T->left);
                LeafNodes(T->right);
            }
        }
    } // print leaf nodes of the tree
    bool isSparseTree(Node *T)
    {
        if (T == NULL || (T->left == NULL && T->right == NULL))
            return true;
        else
        {
            Node *lchild = T->left;
            while (lchild != NULL)
            {
                if (!isSparseTree(lchild))
                    return false;
                lchild = lchild->right;
            }
            return true;
        }
    } // return tree in case tree is filled less than 50%
    void visualizeTree(Node *T);// provide visualization of tree on console

private:
    Node *root;
};

main()
{
    int values[] = {4, 5, 675, 2345, 75, 35};
    Node *root = nullptr;
    BST t;
    for (auto i : values)
    {
        root = t.insertNode(values[i]);
    }
}