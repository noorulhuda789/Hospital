import sys

class Node():
    def __init__(self, item):
        self.item = item
        self.parent = None
        self.left = None
        self.right = None
        self.color = 1

class RBT():
    def __init__(self):
        self.TNULL = Node(0)
        self.TNULL.color = 0
        self.TNULL.left = None
        self.TNULL.right = None
        self.root = self.TNULL
    # Helping functions
    def __rb_transplant(self, u, v):
        if u.parent == None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent
    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.TNULL:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.TNULL:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y
    def fix_insert(self,k):
        while k.parent.color == 1:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == 1:
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == 1:
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = 0
     
        
    def delete_node_helper(self,node,key):
        z = self.TNULL
        while node !=self.TNULL:
            if node.item == key:
                z = node
            elif node.item > key :
                node = node.left
            else:
                node = node.right
        if z == self.TNULL:
            print("Cannot find key in the tree")
        y = z
        yOrigColor = y.color
        if (y.left == self.TNULL):
            x = y.right
            self.transplant(y,y.right)
        elif (y.right == self.TNULL):
            x = y.left
            self.transplant(y,y.left)
        else:
            y = self.minValueNode(y.right)
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y,y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z,y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
            if yOrigColor ==1:
                return
        if (yOrigColor == 0):
            self.deleteFixUp(x)
    def deleteFixUp(self,x):
        while x != self.root and x.color == 'black':
            if x == x.parent.left:
                w = x.parent.right
                if w.color == 1:
                    w.color = 0
                    x.parent.color = 1
                    self.left_rotate(x.parent)
                    w = x.parent.right
                if (w.left.color==0 and w.right.color==0):
                        w.color=1
                elif (w.right.color==0):
                    w.color=0
                    self.right_rotate(w)
                else:
                    w.color=0
                    x.parent.color=1
                    self.left_rotate(x.parent)
            else:
                w = x.parent.left
                if w.color == 1:
                    w.color = 0
                    x.parent.color = 1
                    self.right_rotate(x.parent)
                    w = x.parent.left
                    if (w.right.color==0 and w.left.color==0):
                        w.color=1
                    elif (w.left.color==0):
                        w.color=0
                        self.left_rotate(w)
                    else:
                        w.color=0
                        x.parent.color=1
                        self.right_rotate(x.parent)
            x = x.parent
            

                

    def transplant(self,u,v):
        if u.parent == None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
            v.parent = u.parent
    
    def minValueNode(self,node):
        current = node
    def successor(self,x):
        if x.right!=self.TNULL:
            return self.minValueNode(x.right)
        parent = x.parent
        while parent != self.TNULL and x==parent.right:
            x=parent
            parent=parent.parent
            return parent
    def minValueNode(self,node):
        current = node
        while(current.left != self.TNULL):
            current = current.left
        return current
    def __print_helper(self, node, indent, last):
        if node != self.TNULL:
            sys.stdout.write(indent)
            if last:
                sys.stdout.write("R----")
                indent += "     "
            else:
                sys.stdout.write("L----")
                indent += "|    "

            s_color = "RED" if node.color == 1 else "BLACK"
            print(str(node.item) + "(" + s_color + ")")
            self.__print_helper(node.left, indent, False)
            self.__print_helper(node.right, indent, True)  

    # Insertion in Red Black Tree
    def insert(self, root , key):
        node = Node(key)
        node.parent = None
        node.item = key
        node.left = self.TNULL
        node.right = self.TNULL
        node.color = 1
        y = None
        x = self.root

        while x != self.TNULL:
            y = x
            if node.item < x.item:
                x = x.left
            else:
                x = x.right

        node.parent = y
        if y == None:
            self.root = node
        elif node.item < y.item:
            y.left = node
        else:
            y.right = node

        if node.parent == None:
            node.color = 0
            return

        if node.parent.parent == None:
            return
    def delete(self,item):
        self.de
    def printTree(self):
        self.__print_helper(self.root, "", True)
if __name__ == "__main__":
    my_tree = RBT()
    keys = [50,30,20,40,70,60,80]
    my_tree.root.item = keys[0]
    my_tree.root.color = 0
    for i in range(1,len(keys)):
        my_tree.insert(my_tree.root,keys[i])
    my_tree.printTree()


