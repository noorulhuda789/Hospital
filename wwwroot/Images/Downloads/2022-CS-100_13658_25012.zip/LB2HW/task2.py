def min_coin_change(coins, target):
    # Initialize the dp array with infinity for all values except 0
    dp = [float('inf')] * (target + 1)
    dp[0] = 0

    # Iterate over each coin
    for coin in coins:
        for x in range(coin, target + 1):
            dp[x] = min(dp[x], dp[x - coin] + 1)

    # If dp[target] is still infinity, it means target cannot be reached
    return dp[target] if dp[target] != float('inf') else -1

# Example usage
coins = [1, 2, 5]
target = 11
print(f"Minimum coins required: {min_coin_change(coins, target)}")