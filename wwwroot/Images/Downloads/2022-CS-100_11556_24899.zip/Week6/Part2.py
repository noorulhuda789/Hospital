# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 19:27:13 2023

@author: HP
"""
A = [8,6,4,2,7,3,2,6,9,5,6]
def CountingSort(A, n, k):
    B = [0] * n
    C = [0] * (k + 1)

    for j in range(n):
        C[A[j]] += 1

    for i in range(1, k+1):  
        C[i] += C[i - 1]

    j = n - 1 
    while j >= 0:
        B[C[A[j]] - 1] = A[j]  #adjusting the indices to follow the 0-based indexing
        C[A[j]] -= 1
        j -= 1

    return B
def RadixSort(A):
    max1 = max(A)
    #do insertion sort for every digit
    exp = 1
    while max1 // exp>=1:
        A = CountingSort(A,len(A),max1)
        exp *=10
    return A
A = RadixSort(A)
print(A)