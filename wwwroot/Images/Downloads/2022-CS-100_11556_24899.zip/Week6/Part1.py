# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 08:50:41 2023

@author: HP
"""
A = [8,6,4,2,7,3,2,6,9,5,6]
def CountingSort(A, n, k):
    B = [0] * n
    C = [0] * (k + 1)

    for j in range(n):
        C[A[j]] += 1

    for i in range(1, k+1):  
        C[i] += C[i - 1]

    j = n - 1 
    while j >= 0:
        B[C[A[j]] - 1] = A[j]  #adjusting the indices to follow the 0-based indexing
        C[A[j]] -= 1
        j -= 1

    return B

maximum = max(A)
arr = CountingSort(A, len(A), maximum)
print(arr)

    