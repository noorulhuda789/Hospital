# -*- coding: utf-8 -*-
"""
Created on Sun Oct 15 19:27:33 2023

@author: HP
"""
A = [8,6,4,2,7,3,2,6,9,5,6]
def InsertionSort(array,start,end):
    for i in range(1,end): # starting from 1th index element instead of 0th
        key = array[i] #current element
        j = i-1 # previous element
        while j>=0 and key<array[j]: #comparing current element with previous element
            array[j+1] = array[j] #moving one element forward
            j-=1 
        array[j+1] = key
    return array
    
def BucketSort(A, n):
    if n <= 0:
        return A

    # Create empty buckets
    B = [[] for _ in range(n)]

    # Distribute elements into buckets
    for i in range(1,n):
        B[n*A[i]] = A[i]

    # Sort individual buckets using insertion sort
    for i in range(n):
        InsertionSort(B[i], 0, len(B[i]))  # Pass the start and end indices

    # Concatenate the sorted buckets to get the sorted array
    k = 0
    for i in range(n):
        for j in range(len(B[i])):
            A[k] = B[i][j]
            k += 1

    return A

# Example usage:
A = [8, 6, 4, 2, 7, 3, 2, 6, 9, 5, 6]
n = len(A)
BucketSort(A, n)
print(A)

        
        