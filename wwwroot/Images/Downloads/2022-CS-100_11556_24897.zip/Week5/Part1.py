# -*- coding: utf-8 -*-
"""
Created on Sun Oct  8 04:58:51 2023

@author: HP
"""
A = []
import random
min = -15000
max = 15000
def RandomArray(size):
    for i in range(0,size):
        num = random.randint(min,max)
        A.append(num)
    return A
def Quicksort(A,p,r):
    if p<r:
        q = Partition(A,p,r)
        Quicksort(A, p, q-1)
        Quicksort(A, q+1, r)
def Partition(A,p,r):
    x = A[r]
    i = p-1
    for j in range(p,r-1):
        if A[j]<= x:
            i=i+1
            A[i],A[j] = A[j],A[i]
    A[i+1],A[r] = A[r],A[i+1]
    return i+1
size = 30000
A = RandomArray(size)
#print(A," \n \t RandomNumbers Array \n")
ans = []
import time
start_time = time.time()
start = 0
end = size
ans = A[start:end]
Quicksort(ans, start, end-1)
end_time = time.time()
runtime = end_time - start_time
print(ans)
print("Runtime of Quicksort is",runtime,"seconds")
#File Handling
# Writing into the file
f = open("SortedQuicksort.csv", "w")
for i in range(start,end):
 f.write (str(ans[i]) + "\n")
f.close()           
    