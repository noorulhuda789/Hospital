--Q1
select ProductName from Products where UnitPrice > (select AVG(UnitPrice) from Products);
--Q2
select ShippedDate,count(Year(ShippedDate)) as numberOfOrders from Orders group by ShippedDate having ShippedDate is not null
--Q3
select Country from Suppliers group by Country having count(Country)>=2
--Q4
select Month(ShippedDate) as Month,count(Month(ShippedDate)) as OrdersDelayed from (select * from Orders where RequiredDate < ShippedDate) as T group by Month(ShippedDate)
--Q5
SELECT OrderID, SUM(Discount) AS TotalDiscount FROM [Order Details] WHERE Discount > 0 GROUP BY OrderID;
--Q6
select ShipCity,Count(ShipCity) as numberOfOrders from Orders where ShipCountry = 'USA' and Year(ShippedDate) = 1997 group by ShipCity
--Q7
select DISTINCT ShipCountry,count(Year(ShippedDate)) as OrdersDelayed from (select * from Orders where RequiredDate < ShippedDate) as T group by ShipCountry;
--Q8
SELECT OrderID, SUM(Discount) AS TotalDiscount,SUM(UnitPrice*Quantity) as [Total Price] FROM [Order Details] WHERE Discount > 0 GROUP BY OrderID,UnitPrice;
--Q9
select ShipRegion,ShipCity,Count(ShipCity) as numberOfOrders from Orders where YEAR(ShippedDate) = 1997 group by ShipRegion,ShipCity