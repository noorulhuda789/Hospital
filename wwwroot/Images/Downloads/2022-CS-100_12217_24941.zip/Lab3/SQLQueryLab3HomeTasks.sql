--Q1
select OrderID,CustomerID,RequiredDate,ShippedDate from Orders where ShippedDate > RequiredDate;
--Q2
SELECT COUNT(DISTINCT country) AS country_count, country FROM employees GROUP BY country;
--Q3
select EmployeeID,FirstName+LastName as Name,Title,TitleOfCourtesy,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,notes,PhotoPath from Employees where ReportsTo is null
--Q4
select ProductName from Products where Discontinued =1
--Q5
select OrderID from [Order Details] where Discount =0;
--Q6
select ContactName CustomerName from Customers where Region is NULL
--Q7
select ContactName CustomerName, phone ContactNumber from Customers where Country = 'UK' or Country= 'USA';
--Q8
select CompanyName from Suppliers where HomePage is not null
--Q9
select ShipCountry from Orders where year(ShippedDate) = 1997
--Q10
select CustomerID from Orders where ShippedDate is null
--Q11
select SupplierID,CompanyName,City from Suppliers
--Q12
select EmployeeID,FirstName+LastName as Name,Title,TitleOfCourtesy,HireDate,Address,City,Region,PostalCode,Country,HomePhone,Extension,Photo,notes,PhotoPath,Region from Employees where City = 'London'
--Q13
select ProductName from Products where Discontinued = 0
--Q14
select OrderID from [Order Details] where Discount <= 0.1
--Q15
select EmployeeID,FirstName+LastName as Name,HomePhone as ContactNumber from Employees where Region is Null
